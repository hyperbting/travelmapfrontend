go get github.com/skip2/go-qrcode
go get github.com/gorilla/mux
go build -o bin/application application.go
